import React from "react";
import { Link } from "react-router-dom";

function Navbutton(image) {
  return (
    <>
    <img src={image} alt="버튼이미지" />
    </>
  );
}
export default Navbutton;
