import React from "react";

function RoomCam() {
  return (
    <>
      
    </>
  );
}
export default RoomCam;
