import React from "react";

function RoomPlanModal() {
  return (
    <>
      
    </>
  );
}
export default RoomPlanModal;
